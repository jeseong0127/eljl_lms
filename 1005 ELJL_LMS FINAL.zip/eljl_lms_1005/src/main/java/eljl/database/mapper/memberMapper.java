package eljl.database.mapper;

import eljl.factory.bean.UserInfoBean;

public interface memberMapper {
   
	void joinTeacherCtl(UserInfoBean ub);
	
}
