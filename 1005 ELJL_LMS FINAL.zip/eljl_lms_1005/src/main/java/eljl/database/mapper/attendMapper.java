package eljl.database.mapper;

import java.util.List;

import eljl.factory.bean.StuManageBean;

public interface attendMapper {
   
	public List<StuManageBean> test(StuManageBean smb);
	
}
