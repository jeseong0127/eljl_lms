package eljl.database.mapper;

public interface dashboardMapper {

}
