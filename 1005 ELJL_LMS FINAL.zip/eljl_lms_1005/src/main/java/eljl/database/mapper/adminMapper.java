package eljl.database.mapper;

public interface adminMapper {

}
