package eljl.factory.bean;

import java.util.Date;

import lombok.Data;

@Data
public class CalendarBean {
	String title;
	String start;
	String end;
	String backgroundColor;
}
