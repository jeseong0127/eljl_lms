package eljl.factory.bean;

import lombok.Data;

@Data
public class GradeBean {
	String mbId;
	String csCode;
	String csName;
	String opCode;
	String opName;
	String itemCode;
	String itemName;
	String itemPercent;
	
}
