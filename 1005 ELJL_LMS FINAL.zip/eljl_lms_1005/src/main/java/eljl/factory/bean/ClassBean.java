package eljl.factory.bean;

import lombok.Data;

@Data
public class ClassBean {
	String mbId;
	String csCode;
	String csName;
	
	
	
}
